<form action="{{ route('admin.home.store') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <label for="name">Name</label>
    <input type="text" name="name" required>
    
    <label for="position">Position</label>
    <input type="text" name="position" required>
    
    <label for="photo">Photo</label>
    <input type="file" name="photo" required>
    
    <button type="submit">Save</button>
</form>
