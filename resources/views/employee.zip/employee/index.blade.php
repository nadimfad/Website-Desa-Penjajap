@foreach($employees as $employee)
    <div>
        <img src="{{ asset('storage/' . $employee->photo) }}" alt="photo" width="100">
        <p>{{ $employee->name }}</p>
        <p>{{ $employee->position }}</p>
        <a href="{{ route('admin.home.edit', $employee->id) }}">Edit</a>
        <form action="{{ route('admin.home.destroy', $employee->id) }}" method="POST" onsubmit="return confirm('Are you sure?')">
            @csrf
            @method('DELETE')
            <button type="submit">Delete</button>
        </form>
    </div>
@endforeach
<a href="{{ route('admin.home.create') }}">Add New Employee</a>
