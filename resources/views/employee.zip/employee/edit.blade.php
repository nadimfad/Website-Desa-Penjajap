<form action="{{ route('admin.home.update', $employee->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    
    <label for="name">Name</label>
    <input type="text" name="name" value="{{ $employee->name }}" required>
    
    <label for="position">Position</label>
    <input type="text" name="position" value="{{ $employee->position }}" required>
    
    <label for="photo">New Photo</label>
    <input type="file" name="photo">
    
    <button type="submit">Update</button>
</form>
